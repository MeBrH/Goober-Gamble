import random

amount = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
suits = {
    "1": "♠",
    "2": "♣",
    "3": "♥",
    "4": "♦"
}

deck = [(a, suits[s]) for a in amount for s in suits]

def shuffle():
    return random.shuffle(deck)

def draw():
    return deck.pop()

def to_text(card):
    a, s = card
    return f"{a}{s}"

def card_split(card):
    return (card[0], card[1])