import random
import deck
import os
import json
import sys

def getfileloc():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.abspath(__file__))

fileloc = getfileloc()
PATH = os.path.join(fileloc, "saves")

os.makedirs(PATH, exist_ok=True)

class Player:
    def __init__(self):
        print("Version 4.2.0")
        print("Welcome to Goober Gamble.")
        self.run = False
    
    def get_save(self):
        print("What save do you want to play?")
        self.savechoise = input()
        path_to = f"save{self.savechoise}.json"
        self.SAVE_FILE = os.path.join(PATH, path_to)
        if os.path.exists(self.SAVE_FILE):
                with open(self.SAVE_FILE, "r") as f:
                    data = json.load(f)
                    self.money = data.get("money", 100)
                    self.highscore = data.get("highscore", 100)
                    self.found = True
        else:
            self.money = 100
            self.highscore = 100
            self.found = False
            self.run = True
            print(f"Your money is: €{self.money}")

    def delete_save(self):
        print(f"Your money is: €{self.money}")
        print(f"Your highscore is: €{self.highscore}")
        delete = Player.get_input(self, "Do you want to delete your save?", "", "Yes or no.", "",["yes", "no"])
        if delete == "yes":
            self.delete_s = Player.get_input(self, "Are you sure?", "", "Yes or no.", "",["yes", "no"])
            if self.delete_s == "yes":
                os.remove(PATH)
                print("Save removed. :(")

    
    def reset_save(self):
        reset = Player.get_input(self, "Do you want to reset your save?", "", "Yes or no.", "",["yes", "no"])
        if reset == "yes":
            print("Ok.")
            with open(self.SAVE_FILE, "w") as f:
                json.dump({"money": 100, "highscore": 100}, f)
        self.run = True
    
    def save_score(self):
        with open(self.SAVE_FILE, "w") as f:
            json.dump({"money": self.money, "highscore": self.highscore}, f)


    def get_input(self, prompt, prompt_2, response, prompt_3=None, options=None):
        print(prompt)
        if not prompt_2 == "":
            print(prompt_2)
        while True:
            choice = input(prompt_3).lower().strip()
            if choice in options:
                return choice
            else:
                print(response)
    
    def get_bet(self, game):
        while True:
            allin = 0
            print("Please insert your bet.")
            game.bet = input("€")
            if "." in game.bet and len(game.bet.split(".")[1]) > 2:
                print("Maximum of 2 decimal places.")
                continue
            else:
                try:
                    game.bet = round(float(game.bet),2)
                    if game.bet == self.money:
                        allin = Player.get_input(self, "Are You sure?", "", "Yes or no.", "",["yes", "no"])
                        if allin == "yes":
                            print("Good luck.")
                        else:
                            print("You fucking pussy!")

                    if allin == "yes":
                        break
                    elif self.money > game.bet > 0:
                        break
                    elif game.bet == 0:
                        print("Get your broke ass out of this casino!")
                        p.save_score()
                        raise SystemExit
                    elif game.bet < 0:
                        print("You cannot bet negative money.")
                    elif game.bet > self.money:
                        print("You dont have the money.")

                except ValueError:
                    print("Not an number.")    

class Game:
    def __init__(self):
        self.op = 0
        self.bet = 0
        self.bet_on = 0
        self.game_choise = 0
        self.win = "lost"
        self.factor = 0
        self.comp = 0
        self.card1 = 0
        self.a1, self.s1 = 0, 0
        self.card2 = 0
        self.a2, self.s2 = 0, 0
        self.card3 = 0
        self.a3, self.s3 = 0, 0
        self.card4 = 0
        self.a3, self.s3 = 0, 0
        self.con = "no"
        self.stage = 1
        
    
    def gamechoise(self):
        self.game_choise = Player.get_input(self, "Coinflip, dice, rock, paper, scissors(rps), or ride the bus(rtb).","", "Not an option.", "", ["coinflip", "dice", "rps", "rtb"])

    def c_run(self):
        self.bet_on = Player.get_input(self, "Heads or tails?", "", "Not an option.", "", ["heads", "tails"])
        self.comp = random.choice(("heads", "tails"))
        print(f"The coin landed on: {self.comp}.")
    
    def c_win(self):
        if self.bet_on == self.comp:
            self.win = "won"
            self.factor = 0.5
    
    def d_run(self):
        print("Pick an number through 1 till 6.")
        while True:
            try:
                self.bet_on = int(input())
                if self.bet_on in range(1,7):
                    break
                else:
                    print("Not an option.")
            except ValueError:
                print("Not an number.")
        self.comp = random.randint(1, 6)
        print(f"The dice landed on: {self.comp}.")
    
    def d_win(self):
        if self.bet_on == self.comp:
            self.win = "won"
            self.factor = 2
    
    def rps_run(self):
        self.bet_on = Player.get_input(self, "Rock, paper, or scissors?", "","Not an option.", "", ["rock", "paper", "scissors"])
        self.comp = random.choice(("rock", "paper", "scissors")) 
        print(f"Your opponent chose: {self.comp}.")
    
    def rps_win(self):
        if self.bet_on == "rock" and self.comp == "scissors":
            self.win = "won"
            self.factor = 1
        elif self.bet_on == "paper" and self.comp == "rock":
            self.win = "won"
            self.factor = 1
        elif self.bet_on == "scissors" and self.comp == "paper":
            self.win = "won"
            self.factor = 1
        elif self.bet_on == self.comp:
            self.win = "draw"
            self.factor = 1

    def rtd_con(self):
        self.con = Player.get_input(self, "Continue?", "", "Yes or no.", "",["yes", "no"])
    
    def rtd_s1(self):
        self.bet_on = Player.get_input(self, "Red or black?", "", "Not an option.", "", ["red", "black"])
        deck.shuffle()
        self.card1 = deck.draw()
        self.a1, self.s1 = deck.card_split(self.card1)
        self.card1 = deck.to_text(self.card1)
        print(f"The card was: {self.card1}")
        if self.bet_on == "red" and self.a1 in ("Di","He") or self.bet_on == "black" and self.a1 in ("Cl","Sp"):
            self.win = "won"
            self.factor = 0.5
            print("You won!")
        else:
            self.win = "lost"
        self.stage = 2
    
    def rtd_s2(self):
        self.bet_on = Player.get_input(self, f"Higher or lower than: {self.card1}.", "", "Not an option.", "", ["higher", "lower"])
        self.card2 = deck.draw()
        self.a2, self.s2 = deck.card_split(self.card2)
        self.card2 = deck.to_text(self.card2)
        print(f"The card was: {self.card2}")
        if self.bet_on == "higher" and self.a2>self.a1 or self.bet_on == "lower" and self.a2<self.a1:
            self.win = "won"
            self.factor = 1
            print("You won!")
        else:
            self.win = "lost"
        self.stage = 3
    
    def rtd_s3(self):
        self.bet_on = Player.get_input(self, f"Between: {self.card1} and {self.card2}?", "", "Yes or No.", "", ["yes", "no"])
        self.card3 = deck.draw()
        self.a3, self.s3 = deck.card_split(self.card3)
        self.card3 = deck.to_text(self.card3)
        if self.bet_on == "yes" and self.a1<self.a3<self.a2 or self.bet_on == "no" and (self.a1>self.a3 or self.a2<self.a3):
            self.win = "won"
            self.factor = 2
            print("You won!")
        else:
            self.win = "lost"
        self.stage = 4
    
    def rtd_s4(self):
        self.bet_on = Player.get_input(self, "♠(1), ♣(2), ♥(3), or ♦(4)?", "", "Yes or No.", "", ["1", "2", "3", "4"])
        self.card4 = deck.draw()
        self.a4, self.s4 = deck.card_split(self.card4)
        self.card4 = deck.to_text(self.card4)
        if self.bet_on == self.s4:
            self.win = "win"
            self.factor = 3
            print("You won!")
        else:
            self.win = "lost"
        self.stage = 1

    def money_calc(self, player):
        if self.win == "won":
            self.bet *= self.factor
            self.bet = round(self.bet, 2)
            player.money += self.bet
            print(f"You won: €{self.bet}")
        elif self.win == "draw":
            print("draw")
        else:
            print(f"You lost: €{self.bet}")
            player.money -= self.bet
        self.win = "lost"
        if player.highscore < player.money:
            player.highscore = player.money


    def cashout(self, player):
        print(f"Your money is: €{player.money:.2f}")
        cashout = Player.get_input(self, "Do you want to cashout?", "", "Yes or no", "", ["yes","no"])
        if cashout == "yes":
            print("Already leaving?")
            print(f"Your highscore is: €{player.highscore:.2f}")
            p.save_score()
            raise SystemExit
        else:
            print("Ok.")
    
    def restart(self, player):
        restart = Player.get_input(self, "You lost all your money. Haha!", "Do you want to restart?", "Yes or no.", "", ["yes","no"])
        if restart == "Yes":
            print("Goodluck.")
            player.money = 100
        else:
            print("Bye!")
            print(f"Your highscore is: €{player.highscore:.2f}")
            p.save_score()
            raise SystemExit
    
p = Player()
g = Game()

while True:
    while p.run:
        print(f"Your highscore is: €{p.highscore}")
        g.gamechoise()
        p.get_bet(g)

        if g.game_choise == "coinflip":
            g.c_run()
            g.c_win()
        elif g.game_choise == "dice":
            g.d_run()
            g.d_win()
        elif g.game_choise == "rps":
            g.rps_run()
            g.rps_win()
        else:
            g.rtd_s1()
            if g.win == "won":
                g.rtd_con()
            if g.con == "yes" and g.stage == 2 and g.win == "won":
                g.rtd_s2()
                if g.win == "won":
                    g.rtd_con()
            elif g.con == "yes" and g.stage == 3 and g.win == "won":
                g.rtd_s3()
                if g.win == "won":
                    g.rtd_con()
            elif g.con == "yes" and g.stage == 3 and g.win == "won":
                g.rtd_s4()
            elif g.con == "no" and g.win == "won":
                print("You fucking pussy!")
            g.stage = 1
            
        g.money_calc(p)

        if p.money > 0:
            g.cashout(p)
        else:
            g.restart(p)
    else:
        while True:
            p.get_save()
            if p.found == True:
                p.delete_save()
                if p.delete_s == "no":
                    p.reset_save()
                    break
            else:
                break